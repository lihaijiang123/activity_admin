<?php
return [
    'pathinfo_depr'          => '/',
];