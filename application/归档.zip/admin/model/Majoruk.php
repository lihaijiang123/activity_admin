<?php
namespace app\admin\model;

use think\Model;

class Majoruk extends Model
{
	// 表名
	protected $name = 'siging_major_uk';
	// 主键
	protected $pk = 'major_id';
}