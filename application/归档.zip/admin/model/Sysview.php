<?php
namespace app\admin\model;

use think\Model;

class Sysview extends Model
{
	// 表名
	protected $name = 'sys_view';
	// 主键
	protected $pk = 'Sysview_id';
}