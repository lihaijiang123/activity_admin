<?php
namespace app\admin\model;

use think\Model;

class Users extends Model
{
	// 表名
	protected $name = 'siging_users';
	// 主键
	protected $pk = 'user_id';
}