<?php
namespace app\admin\model;

use think\Model;

class ServeCategory extends Model
{
	// 表名
	protected $name = 'act_serve_category';
	// 主键
	protected $pk = 'id';
}