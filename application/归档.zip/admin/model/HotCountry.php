<?php


namespace app\admin\model;


use think\Model;

class HotCountry extends Model
{
    // 表名
    protected $name = 'act_hot_country';
    // 主键
    protected $pk = 'id';


}