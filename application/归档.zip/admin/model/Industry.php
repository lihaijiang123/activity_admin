<?php


namespace app\admin\model;


use think\Model;

class Industry extends Model
{
    // 表名
    protected $name = 'act_industry';
    // 主键
    protected $pk = 'id';


}