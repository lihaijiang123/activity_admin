<?php

namespace app\admin\model;

use think\Model;

class Organize extends Model
{
    // 表名
    protected $name = 'act_organize';
    // 主键
    protected $pk = 'id';

}