<?php
namespace app\admin\model;

use think\Model;

class ?{{module}}? extends Model
{
	// 表名
	protected $name = '?{{Database}}?';
	// 主键
	protected $pk = '?{{major}}?';
}