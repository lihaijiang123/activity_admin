<?php
namespace app\home\model;
use think\Model;
class AnliModel extends Model
{
	protected $table = 'siging_school_anli';
}