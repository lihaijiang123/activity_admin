<?php
namespace app\home\model;
use think\Model;
class ProductsModel extends Model
{
	protected $table = 'siging_product';

    
}