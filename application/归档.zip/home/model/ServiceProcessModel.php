<?php
namespace app\home\model;
use think\Model;
class ServiceProcessModel extends Model
{
	protected $table = 'service_process';
}