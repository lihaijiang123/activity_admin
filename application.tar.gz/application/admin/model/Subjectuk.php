<?php
namespace app\admin\model;

use think\Model;

class Subjectuk extends Model
{
	// 表名
	protected $name = 'siging_subject_uk';
	// 主键
	protected $pk = 'id';
}