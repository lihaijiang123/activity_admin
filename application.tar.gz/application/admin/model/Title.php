<?php
namespace app\admin\model;

use think\Model;

class Title extends Model
{
	// 表名
	protected $name = 'test_title';
	// 主键
	protected $pk = 'id';
}