<?php
namespace app\admin\model;

use think\Model;

class Bannerwall extends Model
{
	// 表名
	protected $name = 'siging_banner_wall';
	// 主键
	protected $pk = 'id';
}