<?php
namespace app\admin\model;

use think\Model;

class Banner extends Model
{
	// 表名
	protected $name = 'act_banner';
	// 主键
	protected $pk = 'id';
}