<?php
namespace app\admin\model;

use think\Model;

class Serve extends Model
{
	// 表名
	protected $name = 'act_serve';
	// 主键
	protected $pk = 'id';
}