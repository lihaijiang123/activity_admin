<?php
namespace app\admin\model;

use think\Model;

class Titless extends Model
{
	// 表名
	protected $name = 'title_title';
	// 主键
	protected $pk = 'id';
}