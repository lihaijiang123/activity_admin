<?php
namespace app\admin\model;

use think\Model;

class Sysmodule extends Model
{
	// 表名
	protected $name = 'sys_module';
	// 主键
	protected $pk = 'sys_module_id';
}