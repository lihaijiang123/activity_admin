<?php
namespace app\admin\model;

use think\Model;

class Anli extends Model
{
	// 表名
	protected $name = 'siging_school_anli';
	// 主键
	protected $pk = 'id';
}