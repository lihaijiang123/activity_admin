<?php
namespace app\admin\model;

use think\Model;

class Tutorcase extends Model
{
	// 表名
	protected $name = 'siging_case';
	// 主键
	protected $pk = 'id';
}