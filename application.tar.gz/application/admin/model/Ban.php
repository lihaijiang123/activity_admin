<?php
namespace app\admin\model;

use think\Model;

class Ban extends Model
{
	// 表名
	protected $name = 'ban';
	// 主键
	protected $pk = 'id';
}