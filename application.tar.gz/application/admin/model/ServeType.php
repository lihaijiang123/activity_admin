<?php
namespace app\admin\model;

use think\Model;

class ServeType extends Model
{
	// 表名
	protected $name = 'act_serve_type';
	// 主键
	protected $pk = 'id';
}