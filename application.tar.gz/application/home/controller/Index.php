<?php
namespace app\home\controller;
use think\facade\Request;
use think\Controller;
use app\home\model\SchoolModel;
use app\home\model\AnliModel;
use think\db;

// 首页控制器
class Index extends Common{

     public function initialize()
    {
        parent::initialize();
        $city_con = file_get_contents('city_json.txt');
        $city_con_decode = json_decode($city_con,true);
        foreach ($city_con_decode as $key => $val) {
            $this->city_arr[$key]['id'] = $val['id'];
            $this->city_arr[$key]['city'] = $val['city'];
        }

        $this->city_arr = change_key($this->city_arr);
    }

    /**
     * @Author   JFY
     * @DateTime 2020-05-11
     * @Describe [describe]
     * @Purpose  [purpose]
     * @param    [userId 用户id 必填]
     * @param    [page 页码 选填]
     * @param    [city 城市 选填]
     * @param    [serve_type_id 活动类型id 选填]
     * @return   [type]     [description]
     */
    public function index(){
    	$data = input();
    	$page = empty($data['page']) ? 1 : $data['page'] ;

    	// 搜索条件
    	$search_where = [];
    	// 返回值
    	$return = [];

    	// 活动类型
    	$active_types = Db::name('act_serve_type')->field('id,title')->order('sort desc')->where('status','=',1)->select();

    	// banner
    	$banners = Db::name('act_banner')->field('id,title,img,url')->order('sort desc')->where('status','=',1)->select();
    	if( !empty($banners) ){
    		foreach ($banners as $key => &$val) {
    			$val['img'] = config('admin_path') . $val['img'];
    		}
    	}
    	// 热门活动
    	if( !empty($data['city']) ){
    		$search_where[] = ['search_city', '=', $data['city']];
    	}
    	if( $data['serve_type_id'] != 0 ){
    		$search_where[] = ['serve_type_id', 'like', "%" . $data['serve_type_id'] . "%"];
    	}else{
            $search_where[] = ['serve_type_id', '<>', ''];
        }

    	$active_list = Db::name('act_serve')
    					->field('id,title,pay_mode,pic,begin_time,end_time')
    					->order('sort desc')
    					->where([['status','=',1],['is_hot','=',1]])
    					->where( $search_where )
    					->paginate(array('list_rows' => config('pageSize'), 'page' => $page))
    					->toArray();
        
    	if( !empty($active_list['data']) ){
    		foreach ($active_list['data'] as $key => &$val) {
    			$val['pic'] = config('admin_path') . $val['pic'];
                $val['begin_time'] = date('m-d H:i',$val['begin_time']);
                $val['end_time'] = date('m-d H:i',$val['end_time']);
    		}
    	}
    	
        array_unshift($active_types,['id'=>0,'title'=>'全部']);
    	$return['active_types'] = $active_types;
    	$return['banners'] = $banners;
    	$return['active_list'] = $active_list;
    	return json_msg(0,'成功',$return);
    }

    /**
     * @Author   JFY
     * @DateTime 2020-05-13
     * @Describe [活动详情]
     * @Purpose  [purpose]
     * @param    [param]
     * @return   [type]     [description]
     */
    public function activity_detail(){
        $data = input();
        $info = Db::name('act_serve')->where([['id','=',$data['activity']]])->field('id,title,see_num,cang_num,pay_mode,begin_time,end_time,hold_mode,content,pic,city,address')->find();
        // 浏览量+1
        $info['begin_time'] = date('m-d H:i',$info['begin_time']);
        $info['end_time'] = date('m-d H:i',$info['end_time']);
        $info['pic'] = config('admin_path') . $info['pic'];
        if( !empty($info['city']) ){
            $info['city'] = $this->city_arr[$info['city']]['city'];
        }
        // 是否收藏
        // $is_collection = Db::table('act_collection')->where([['userId'=>$data['userId']],['serve_id'=>$data['activity']]])->find();
        $is_collection = Db::table('act_collection')->where('userId','=',$data['userId'])->where('serve_id','=',$data['activity'])->find();
        if( !empty($is_collection['id']) ){
            $info['cang'] = true;
        }else{
            $info['cang'] = false;
        }

        Db::table('act_serve')->where('id', $data['activity'])->setInc('see_num');
        return json_msg(0,'成功',$info);
    }

    /**
     * @Author   JFY
     * @DateTime 2020-05-11
     * @Describe [describe]
     * @Purpose  [purpose]
     * @param    [userId 用户id 必填]
     * @param    [orderType 分享列表|收藏列表 (share|collection) 必填]
     * @param    [pay_mode 线上、线下 选填 (1|2)]
     * @param    [page 页码 选填]
     * @param    [serve_type_id 活动类型id 选填]
     * @param    [order 排序 选填 (time_desc|time_asc)]
     * @return   [type]     [description]
     */
    public function activity(){
    	$data = input();
    	switch ($data['orderType']) {
    		// 分享列表
    		case 'share_list':
    			$this->share_list( $data );
    			break;
    		// 收藏列表
    		case 'collection_list':
    			$this->collection_list( $data );
    			break;
    		default:
    			# code...
    			break;
    	}

    }

    /**
     * @Author   JFY
     * @DateTime 2020-05-11
     * @Describe [分享]
     * @Purpose  [purpose]
     * @param    [param]
     * @return   [type]     [description]
     */
    public function share(){
    	$data = input();
    	$data['create_time'] = time();
    	$is_exists = Db::name('act_share')->where([['userId','=',$data['userId']],['serve_id','=',$data['serve_id']]])->find();
    	$msg = '分享成功';
    	if( !$is_exists ){
    		$res = Db::name('act_share')->insert($data);
    	}
		return json_msg(0,$msg);
    }

    /**
     * @Author   JFY
     * @DateTime 2020-05-11
     * @Describe [收藏]
     * @Purpose  [purpose]
     * @param    [param]
     * @return   [type]     [description]
     */
    public function collection(){
    	$data = input();
    	$data['create_time'] = time();
    	$is_exists = Db::name('act_collection')->where([['userId','=',$data['userId']],['serve_id','=',$data['serve_id']]])->find();
    	if( !$is_exists ){
    		$res = Db::name('act_collection')->insert($data);
    		$msg = '收藏成功';
            // 收藏量+1
            Db::table('act_serve')->where('id', $data['serve_id'])->setInc('cang_num');
    	}else{
    		$res = Db::table('act_collection')->delete($is_exists['id']);
    		$msg = '取消收藏成功';
            // 收藏量-1
            Db::table('act_serve')->where('id', $data['serve_id'])->setDec('cang_num');
    	}
		
		return json_msg(0,$msg);
    }

    // 分享列表
    public function share_list( $data ){

        $page = empty($data['page']) ? 1 : $data['page'] ;

    	$list=Db::name('act_share')
            ->alias('share')
            ->distinct(true)
            ->where('share.userId','=',$data['userId'])
            ->Join('act_serve sever','sever.id=share.serve_id')
            ->field('sever.id, sever.title, sever.pic, sever.begin_time, sever.end_time, sever.see_num, sever.cang_num, sever.pay_mode, sever.hold_mode, search_serve_type as serve_type, address, search_city as city')
            ->order('share.create_time desc')
            ->paginate(array('list_rows' => config('pageSize'), 'page' => $page))
            ->toArray();

        if( !empty($list) ){
            foreach ($list['data'] as $key => &$val) {
                $val['pic'] = config('admin_path') . $val['pic'];
                $val['begin_time'] = date('m-d H:i',$val['begin_time']);
                $val['end_time'] = date('m-d H:i',$val['end_time']);
            }
        }    

        return json_msg(0,'成功',$list);
    }

    // 收藏列表
    public function collection_list( $data ){

    	$page = empty($data['page']) ? 1 : $data['page'] ;

        $list=Db::name('act_collection')
            ->alias('colle')
            ->distinct(true)
            ->where('colle.userId','=',$data['userId'])
            ->Join('act_serve sever','sever.id=colle.serve_id')
            ->field('sever.id, sever.title, sever.pic, sever.begin_time, sever.end_time, sever.see_num, sever.cang_num, sever.pay_mode, sever.hold_mode, search_serve_type as serve_type, address, search_city as city')
            ->order('colle.create_time desc')
            ->paginate(array('list_rows' => config('pageSize'), 'page' => $page))
            ->toArray();


        if( !empty($list) ){
            foreach ($list['data'] as $key => &$val) {
                $val['pic'] = config('admin_path') . $val['pic'];
                $val['begin_time'] = date('m-d H:i',$val['begin_time']);
                $val['end_time'] = date('m-d H:i',$val['end_time']);
            }
        }    

        return json_msg(0,'成功',$list);
    }

    /**
     * @Author   JFY
     * @DateTime 2020-05-18
     * @Describe [搜索列表]
     * @Purpose  [purpose]
     * @param    [param]
     * @return   [type]     [description]
     */
    public function search_list(){
        $data = input();
        $page = empty($data['page']) ? 1 : $data['page'] ;

        // 活动类型
        $active_types = Db::name('act_serve_type')->field('id,title')->order('sort desc')->where('status','=',1)->select();
        
        $where[] = ['status','=',1];

        $order = $data['order'];
        $hold_mode = $data['hold_mode'];
        $serve_type_id = $data['serve_type_id'];
        $keywords = $data['keywords'];

        // 默认的排序是按照sort降序排列
        if( !empty(explode('__',$order)) ){
            $order = implode(' ',explode('__',$order));
        }else{
            $order = 'sort desc';
        }

        if( !empty($hold_mode) ){
            $where[] = array('hold_mode','=',$hold_mode);
        }else{
            $where[] = array('hold_mode','<>','');
        }

        if( $serve_type_id != 0 ){
            $where[] = array ('serve_type_id', 'like', "%" . $serve_type_id . "%" );
        }else{
            $where[] = array('serve_type_id','<>','');
        }

        if( !empty( $keywords ) ){
            $where[] = array('title','like', "%". $keywords ."%" );
        }

        $active_list = Db::name('act_serve')
                        ->field('id,title,begin_time,end_time,city,pay_mode,pic,serve_type_id,city,address,search_serve_type as serve_type,hold_mode')
                        ->order( $order )
                        ->where([ $where ])
                        ->paginate(array('list_rows' => config('pageSize'), 'page' => $page))
                        ->toArray();

        if( !empty($active_list['data']) ){
            foreach ($active_list['data'] as $key => &$val) {
                $val['pic'] = config('admin_path') . $val['pic'];
                $val['begin_time'] = date('m-d H:i',$val['begin_time']);
                $val['end_time'] = date('m-d H:i',$val['end_time']);
                if( !empty($val['city']) ){
		            $val['city'] = $this->city_arr[$val['city']]['city'];
		        }
            }
        }

        array_unshift($active_types,['id'=>0,'title'=>'全部']);

        $return['active_types'] = $active_types;
        $return['active_list'] = $active_list;
        return json_msg(0,'成功',$return);
    }

}