<?php
namespace app\home\model;
use think\Model;
class BannerwallModel extends Model
{
	protected $table = 'siging_banner_wall';


    
}