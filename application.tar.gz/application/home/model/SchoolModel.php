<?php
namespace app\home\model;
use think\Model;
class SchoolModel extends Model
{
	protected $table = 'siging_school';
}