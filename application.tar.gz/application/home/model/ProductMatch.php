<?php
namespace app\home\model;
use think\Model;
class ProductMatch extends Model
{
	protected $table = 'siging_product_match';

    
}