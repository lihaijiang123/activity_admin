<?php
namespace app\home\model;
use think\Model;
class CaseModel extends Model
{
	protected $table = 'siging_case';

    
}